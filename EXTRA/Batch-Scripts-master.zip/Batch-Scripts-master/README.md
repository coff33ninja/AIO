# Batch-Scripts
A collection of batch scripts I've written over the years.
