BatchScript-Collection
======================

Collection of Batch scripts for the Windows command interpreter (CMD.EXE)


BackupMachine
-------------

A script (prototype) to perform full and/or incremental backups using rsync. Its 
name implies to work similar to Apple's Time Machine backend. As the main 
feature *hard links* are created to a previous backup. Use at your own risk!


CMDA sudo for Windows
---------------------

Just a native sudo for Windows solution as batch script.


Command here
------------

Open command prompt (CMD.EXE) with your working directory from the context menu 
of the Windows Explorer.


DD-WRT router reconnect batch script for Windows
------------------------------------------------

Performs a reconnect of a DD-WRT based routers internet connection.


finded - Find Empty Directories
-------------------------------

Recursive search for empty directories with the option for a callback executed
on each occurrence.


which for Windows
-----------------

The well known console command from Unix/Linux as Batch script for Windows.
