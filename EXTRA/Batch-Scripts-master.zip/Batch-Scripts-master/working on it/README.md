# Batch-Script-Collection

Collection of Batch scripts, examples and some details for various commands are considered. The subjects include system administration, file management, computer maintenance,  Internet tools, and network administration. 

<div align="center">
  <img src="https://raw.githubusercontent.com/happy05dz/Batch-Script-Collection/master/_images/banner.gif" width="auto" height="auto" />
  </div>
  
  
---
## License
[![CC0](http://i.creativecommons.org/p/zero/1.0/88x31.png)](http://creativecommons.org/publicdomain/zero/1.0/)