# Batch-Scripts

Here, I upload many useful batch scripts for doing useful things and tasks on the Win10 platform.
