Replacer v2.63 (x64)(2007-04-15)

1) Beta version is confirmed working on Win10/Win11.
2) This needs to run as administrator or as system to work.

I found this file being hosted at http://www3.telus.net/_/replacer/ previously.
However, it has since went down, but I am hosting it at my GitHub page for preservation.
