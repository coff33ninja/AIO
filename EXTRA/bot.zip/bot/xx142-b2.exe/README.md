![screenshot](/screenshots/400x250-submission-screenshot.png?raw=true)

Hello, xx142-b2.exe

This is the year 2413,
humanity is enslaved by an alien race for more than two centuries already.

You are an AI weaponized virus built to infiltrate the alien network and deactivate all power generators and weapon systems.

The alien antivirus will detect and delete you after 13 seconds.

But remember: a file is never really deleted. Use the execution backtrace from your previous attempts to break in and destroy the main memory core.

---

Controls:

WASD / Arrows - movement

Backspace - kill -9 xx142-b2.exe

---

- Ben Clark and Salvatore Previti

Fist place in the Overall/Desktop category for js13k 2019 - https://2019.js13kgames.com/#in - https://github.blog/2019-10-08-js13k-2019-highlights/
Thanks to js13k organisers and thanks for voting xx142-b2.exe!

MIT license. Copyright (c) 2019 Ben Clark, Salvatore Previti

This game runs in the latest versions of Chrome and Firefox and requires webgl support.

Enjoy :)
