## 👨🏽‍💻 Windows-Optimizer

__Windows-Optimizer is a batch program. This program is Optimizing and Defragmenting All Connected Storage Drives &amp; Fixing File System Errors.__

## 👨🏽‍💻 Installing and Using
⚙️ 1. Download ```Windows-Optimizer``` repository.

⚙️ 2. Extract the ```.zip``` file.

⚙️ 3. Right click on ```Windows-Optimizer.bat```

⚙️ 4. Run as Administrator
