# Contributing Guidelines

None yet.

As this is a very small collection of scripts intended for making your life easier, there are no formal guidelines yet. Everybody is free  to contribute and suggesting changes where one sees room for improvements or fixes. Contribution welcome :)
