WSATools by weareblahs

[What's this all about?]
This is a toolbox that allows you to do Windows Subsystem for Android

[How to run?]
 - Just run WSAToolsLauncher.bat.
   - If you prefer to run immediately without the 3 second waiting, then run WSAToolsLauncher_i.bat.

[What's inside?]
║ Root
╠
╚╠ WSAToolsLauncher - Launcher. Checks your Windows 11 version before running.
 ╠ WSAToolsLauncher_i - Launcher. Checks your Windows 11 version before running.
 ╠ README.txt - This file.
     	    /main
            ╠ 
            ╚╠ InstallAPK - Installs APK files on Windows Subsystem for Android.
             ╠ InstallWSA - Installs Windows Subsystem for Android on your PC.
             ╠ InstallWSAMirror - Installs Windows Subsystem for Android on your PC. Files hosted on my personal OneDrive cloud storage.
             ╠ InstallXAPK - Installs XAPK files downloaded from APKPure.
             ╠ Screenshot - Screenshots the current window from Windows Subsystem for Android. Custom output filename. [Currently not working]
             ╠ ScreenshotDT - Screenshots the current window from Windows Subsystem for Android. Filename follows "YYYYMMDD HHMMSS" format. [Currently not working]
             ╠ UpdateWSA - Updates Windows Subsystem for Android. Requires uninstall of Windows Subsystem for Android.
	     ╠═══ update_check / check_update.bat will be downloaded from this GitHub repo
             ╠ WSATools - Runs WSATools menu. This will run after WSAToolsLauncher check.

[Sharing this project]
To share this project to other sites, please include the following text:
╔════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║													 ║
║ WSATools by weareblahs. Original source code can be found at https://github.com/weareblahs/WSATools.   ║
║ Download it here: https://github.com/weareblahs/WSAtools/releases/					 ║
║													 ║
╚════════════════════════════════════════════════════════════════════════════════════════════════════════╝
You can modify the wording here. Just make sure that you include these 2 links.

[Disclaimer]
This project isn't affliated with Microsoft Corporation or Google.

[Contribution]
Need to change something? Then submit a pull request with the modified source code.
Need to suggest a feature? Then create an issue.