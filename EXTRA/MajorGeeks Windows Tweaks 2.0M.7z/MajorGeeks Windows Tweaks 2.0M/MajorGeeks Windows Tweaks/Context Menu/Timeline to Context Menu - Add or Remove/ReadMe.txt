Timeline is a new feature in Windows 10 Spring Update. If you like to use Timeline frequently, you can add it to your
Context menu (right-click) with this registry hack from MajorGeeks.

Further info:

How to Add Timeline or TaskView to the Windows 10 Context Menu:
http://www.majorgeeks.com/content/page/how_to_add_timeline_or_taskview_to_the_windows_10_context_menu.html

What Is Windows 10 Timeline and How to Use It:
http://www.majorgeeks.com/content/page/what_is_windows_10_timeline_and_how_to_use_it.html

Timeline Feature Not Working in Windows 10:
http://www.majorgeeks.com/content/page/timeline_feature_not_working_in_windows_10.html