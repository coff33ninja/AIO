---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

- **Tell me exactly what the issue is**.

  **Example:** I tried to change my power plan but it didn't work, stated that the plan did not exist

  

- **Give me exact details on what you did to get to the issue.**

  **Example:** I loaded up the script, chose Settings and Tweaks- Windows System Settings- Power Options

  chose "Change Power Plan", Typed MaximumPerformance but it did not set the Plan.

  

- **Screenshots (If possible)**

  

- **What Build, Edition and Architecture are you using: ****

  **Example:** Windows 10 Home 1909 18363.327 64 Bit **


