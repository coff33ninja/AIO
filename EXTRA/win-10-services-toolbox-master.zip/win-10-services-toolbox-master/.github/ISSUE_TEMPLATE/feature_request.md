---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**If you have any suggestions on any tweaks to add, put it here**

**(Optional) If you already know the commands/reg tweak etc. needed for your suggestion, let me know and we will talk about submitting your commit to the script**