Welcome to a massive collection of registry, PowerShell, and batch file tweaks from MajorGeeks.Com

BACKUP. BACKUP. BACKUP. A registry backup should be done before proceeding:
https://www.majorgeeks.com/content/page/how_to_back_up_or_restore_the_windows_registry.html

-------------------------------------------------------------------------------------------------------------
Donations accepted at PayPal - https://www.majorgeeks.com/content/page/donations.html

Check out MajorGeeks. Quality software and tutorials since 2000:
https://www.majorgeeks.com/

Check out all these tweaks individually at:
https://www.majorgeeks.com/mg/sortname/majorgeeks_registry_batch_file_tweaks.html

Check out our YouTube channel:
https://www.youtube.com/user/majorgeeks